import numpy as np
import pandas as pd

class AssignmentEnv:
    def __init__(self, df, rows=3, cols=7):
        self.df = df.copy().reset_index(drop=True)
        # Use your weight matrix; make sure its dimensions match the grid.
        self.weight_matrix = np.array([
            # … your weight matrix data here …
        ])
        self.rows = self.weight_matrix.shape[0]
        self.cols = self.weight_matrix.shape[1]
        self.total_cells = self.rows * self.cols
        
        # We assume each product in df will be assigned once.
        # Optionally, you can extract other features from df.
        self.num_products = len(self.df)
        
    def reset(self):
        """
        For this environment, the reset returns the entire product set.
        For example, we return the dataframe or a numpy array encoding key features.
        Here we simply return the dataframe.
        """
        self.fail_count = 0
        # You can preprocess the dataframe if needed (e.g., extract quantities)
        return self.df.copy()
    
    def step(self, action):
        """
        action: a 1D numpy array (or list) of length num_products.
                Each element is an integer (0 to total_cells-1) indicating
                which cell the corresponding product is assigned to.
                
        The method constructs a grid (matrix) of product indices.
        If a cell receives more than one product, it counts as a collision.
        A huge penalty is applied if there are 3 or more collisions.
        The reward is computed based on the product quantity (from 'UNDESTIMADAS')
        and the weight for the cell where it was placed.
        """
        # Initialize the grid with -1 (meaning empty)
        grid = np.full((self.rows, self.cols), -1, dtype=int)
        collisions = 0
        
        # Process each product's assignment
        for i, cell in enumerate(action):
            row, col = divmod(cell, self.cols)
            if grid[row, col] != -1:
                # A product is already assigned to this cell: count a collision
                collisions += 1
            else:
                grid[row, col] = i  # Store product index or ID as desired
        
        # Calculate reward by summing the penalization for each assigned cell.
        # Here we assume each cell's penalization is: 
        #    -(quantity * weight_matrix[row, col]) / scaling_factor.
        reward = 0.0
        scaling_factor = 10000000.0  # same as before
        for i in range(self.rows):
            for j in range(self.cols):
                prod_idx = grid[i, j]
                if prod_idx != -1:
                    quantity = self.df.loc[prod_idx, 'UNDESTIMADAS']
                    reward += (- quantity * self.weight_matrix[i, j]) / scaling_factor
        
        # Apply huge penalty if too many collisions occurred
        huge_penalty = -100.0
        if collisions >= 3:
            reward = huge_penalty
        
        # In this formulation, each episode is a one-step episode.
        done = True
        
        # Return the resulting matrix (with product assignments), reward, and done flag.
        return grid, reward, done

# Example usage:
if __name__ == "__main__":
    # Load your data frame as before
    file_path = 'productos_anaquel.xls'
    df_list = []
    i = 1
    try:
        while True:
            df_list.append(pd.read_excel(file_path, sheet_name=f"Sheet {i}"))
            i += 1
    except Exception as e:
        pass
    df_all = pd.concat(df_list, ignore_index=True)
    df_all = df_all[df_all['ANAQUEL'].str.startswith('C', na=False)]
    df_all = df_all[df_all['CAMPA'] == 201416]
    df_all.reset_index(drop=True, inplace=True)
    
    # Initialize environment
    env = AssignmentEnv(df_all, rows=3, cols=7)
    observation = env.reset()
    
    # Example: agent outputs an assignment vector (for demonstration, random assignment)
    action = np.random.randint(0, env.total_cells, size=env.num_products)
    
    # Environment evaluates the assignment
    matrix, reward, done = env.step(action)
    print("Assignment Matrix:\n", matrix)
    print("Reward:", reward)
    print("Done:", done)
